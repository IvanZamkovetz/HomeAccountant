var app;
(function (app) {
    var MainController = (function () {
        function MainController($state, $rootScope, $scope, loginService) {
            console.log("MainController.constructor()");
            console.log(this);
            this._$state = $state;
            this._baseAddress = $rootScope.baseAddress;
            this._loginService = loginService;
            this._scope = $scope;
            MainController.prototype._scope = $scope;
            MainController.prototype._$state = this._$state;
            $scope.MainController = this;
            this._scope.sseData = null;
            $scope.$on("loginSucceeded", this.loginSucceeded);
        }
        //listeners
        MainController.prototype.loginSucceeded = function (e, items) {
            console.log("MainController.loginSucceeded()");
            console.log(this);
            MainController.prototype.scopeInit();
            MainController.prototype._$state.go("home");
        };
        MainController.prototype.itemParametersChanged = function (e, itemParam) {
            console.log("MainController.itemParametersChanged()");
            console.log(this);
            this._scope.itemParam = itemParam;
        };
        //events
        MainController.prototype.logOut = function () {
            console.log("MainController.logOut()");
            console.log(this);
            //denie treeView loading data
            //flush Actions Diagramm data
            this._scope.isLogin = false;
            this._scope.$broadcast("logout", null);
            this._loginService.logOut();
            this._$state.go("login");
        };
        //common
        MainController.prototype.scopeInit = function () {
            console.log("MainController.scopeInit()");
            console.log(this);
            //load treeView dataSource
            //load Actions/Schedule dataSource
            this._scope.$broadcast("login", null);
            this.createChart();
            this._scope.$on("itemParametersChanged", this.itemParametersChanged);
            this._scope.isLogin = true;
        };
        MainController.prototype.beginAcceptSse = function () {
            console.log("MainController.beginAcceptSse()");
            console.log(this);
            if (typeof (EventSource) !== undefined) {
                // Yes! Server-sent events support!
                var sseAddress = this._baseAddress + "api/test/get";
                this._eventSource = new EventSource(sseAddress, null);
                this._eventSource.onmessage = function (event) {
                    console.log("headerController.EventSource.OnMessage()");
                    MainController.prototype._scope.sseData = event.data;
                    MainController.prototype._scope.$apply();
                };
                this._eventSource.onerror = function () {
                    console.log("headerController.EventSource.OnError()");
                    alert("sseError");
                };
            }
            else {
                // Sorry! No server-sent events support..
                alert('SSE not supported by browser.');
            }
        };
        MainController.prototype.createChart = function (subItems) {
            if (subItems === void 0) { subItems = null; }
            console.log("foodDiagramm.createChart()");
            var subItems = [{ Name: "someAction1", UnitsNumber: 1 },
                { Name: "someAction2", UnitsNumber: 2 },
                { Name: "someAction3", UnitsNumber: 3 }];
            var chartInstance = new Highcharts.Chart({
                //point click event
                /*
                mark point value as fixed
                save it's value
                */
                chart: {
                    type: 'bar',
                    renderTo: 'balanceChartContainer',
                    animation: false,
                    events: {
                        load: function () {
                            setInterval(function () {
                            }, 5000);
                        }
                    }
                },
                title: {
                    text: 'Balance Diagramm'
                },
                xAxis: {
                    categories: function () {
                        var categories = new Array();
                        $.each(subItems, function (index, product) {
                            categories.push(product.Name);
                        });
                        return categories;
                    }()
                },
                plotOptions: {
                    series: {
                        point: {
                            events: {}
                        },
                        stickyTracking: false
                    },
                    column: {
                        stacking: 'normal'
                    },
                    line: {
                        cursor: 'ns-resize'
                    }
                },
                tooltip: {},
                series: [{
                        data: function () {
                            var data = new Array();
                            $.each(subItems, function (index, product) {
                                data.push(product.UnitsNumber);
                            });
                            return data;
                        }(),
                        //draggableY: true,
                        //dragMinY: 0,
                        type: 'column',
                    }]
            });
        };
        MainController.$inject = ["$state", "$rootScope", "$scope", "loginService"];
        return MainController;
    }());
    app.MainController = MainController;
    angular.module("main").controller("mainController", MainController);
})(app || (app = {}));
//# sourceMappingURL=mainController.js.map