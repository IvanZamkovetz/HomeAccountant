var app;
(function (app) {
    var main = angular.module("main", ["kendo.directives", "ngRoute", "ui.router"], function () {
        console.log("angular.module.function()");
    });
    main.config(["$httpProvider", "$urlRouterProvider", "$stateProvider", function ($httpProvider, $urlRouterProvider, $stateProvider) {
            console.log("angular.module.config()");
            $httpProvider.interceptors.push('bearerInterceptor');
            $urlRouterProvider
                .otherwise("/");
            $stateProvider.state("login", {
                url: "/",
                templateUrl: "login/loginView.html",
                controller: "loginController",
                controllerAs: "vm"
            }).state("home", {
                url: "/home",
                templateUrl: "home/homeView.html",
                controller: "homeController",
                controllerAs: "vm"
            }).state("users", {
                url: "/users",
                templateUrl: "users/usersView.html",
                controller: "usersController",
                controllerAs: "vm"
            }).state("actions", {
                url: "/actions",
                templateUrl: "actions/actionsView.html",
                controller: "actionsController",
                controllerAs: "vm"
            }).state("items", {
                url: "/items/:Id",
                templateUrl: "items/itemsView.html",
                controller: "itemsController",
                controllerAs: "vm",
                params: {
                    Id: { value: "-1" }
                }
            });
        }]);
    main.run(function ($rootScope) {
        console.log("angular.mainModule.run()");
        var responseError = false;
        var responseErrorMessage = "no response error message";
        var bearer = null;
        var baseAddress = "http://www.accounterServer.local.com:9000/";
        $rootScope.responseError = responseError;
        $rootScope.responseError = responseErrorMessage;
        $rootScope.bearer = bearer;
        $rootScope.baseAddress = baseAddress;
        console.log($rootScope.baseAddress);
    });
})(app || (app = {}));
//# sourceMappingURL=main.js.map