﻿module app {
    //is singleton
    //should contain business logic, data
    export class ItemsService {
        private _baseApiService: app.BaseApiService;
        private _subItems: ng.IPromise<any>;
        private _result: ng.IPromise<any>;

        static $inject = ["baseApiService"];
        constructor(baseApiService: app.BaseApiService) {
            console.log("ItemsService.constructor()");
            console.log(this);

            this._baseApiService = baseApiService;
            this._result = null;
            this._subItems = null;
        }
        getSubItems(id: number = null): ng.IPromise<any> {
            console.log("ItemsService.getSubItems()");
            console.log(this);

            var subAddress = "api/items/getSubItems/" + id;
            this._subItems = this._baseApiService.read(subAddress, null);

            return this._subItems;
        }
        addItem(param: any = { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null }): ng.IPromise<any> {
            console.log("ItemsService.addItem()");
            console.log(this);

            var subAddress = "api/items/addItem";
            this._result = this._baseApiService.modify(subAddress, param);

            return this._result;
        }
        editItem(param: any = { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null }): ng.IPromise<any> {
            console.log("ItemsService.editItem()");
            console.log(this);

            var subAddress = "api/items/editItem";
            this._result = this._baseApiService.modify(subAddress, param);

            return this._result;
        }
        deleteItem(id: number = -1, param: any = { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null }): ng.IPromise<any> {
            console.log("ItemsService.deleteItem()");
            console.log(this);

            var subAddress = "api/items/deleteItem/" + id;
            this._result = this._baseApiService.modify(subAddress, param);

            return this._result;
        }
        flushAndDeleteItem(id: number = -1, param: any = { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null }): ng.IPromise<any> {
            console.log("ItemsService.deleteItem()");
            console.log(this);

            var subAddress = "api/items/flushAndDeleteItem/" + id;
            this._result = this._baseApiService.modify(subAddress, param);

            return this._result;
        }

    }

    angular.module("main").service("itemsService", ItemsService);
} 