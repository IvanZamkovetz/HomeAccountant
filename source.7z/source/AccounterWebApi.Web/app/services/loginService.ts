﻿module app {
    //is singleton
    //should contain business logic, data
    export class LoginService {
        private _rootScope: any;
        private _baseAddress: string;

        private _http: ng.IHttpService;
        private _serializer: ng.IHttpParamSerializer;

        private _result: ng.IPromise<any>;
        private _$q: any;

        static $inject = ["$q", "$rootScope", "$http", "$httpParamSerializer"];
        constructor($q, $rootScope: any, $http: ng.IHttpService, serializer: ng.IHttpParamSerializer) {
            console.log("loginService.constructor()");
            console.log(this);

            this._rootScope = $rootScope;
            this._baseAddress = $rootScope.baseAddress;

            this._http = $http;
            this._serializer = serializer;

            this._result = null;
            this._$q = $q;
        }
        logIn(param: any = { username: "default", password: "default" }): ng.IPromise<any> {
            console.log("loginService.logIn()");
            console.log(this);

            var address = this._baseAddress + "oauth/token";
            param.grant_type = "password";

            var config = {
                method: "post",
                url: address,
                data: this._serializer(param),
                headers: { "Content-Type": "application/x-www-form-urlencoded" }
            }

            var defer = this._$q.defer();
            this._result = this._http(config)
                .then((success: any): ng.IPromise<any> => {//
                        console.log("loginService.logIn().responseSuccess()");
                        console.log("access_token: ");
                        console.log(success.data.access_token);

                        //set other login data
                        this._rootScope.bearer = success.data.access_token;
                        defer.resolve(success.data);
                        return defer.promise;

                }, (error) => {
                    console.log("loginService.logIn().responseError()");



                    defer.reject(error.data.error);
                    return defer.promise;
                });

            return this._result;
        }
        logOut() {
            this._rootScope.bearer = null;
            //clear other login data


        }
    }

    angular.module("main").service("loginService", LoginService);
}  