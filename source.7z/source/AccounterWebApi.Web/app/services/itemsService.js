var app;
(function (app) {
    //is singleton
    //should contain business logic, data
    var ItemsService = (function () {
        function ItemsService(baseApiService) {
            console.log("ItemsService.constructor()");
            console.log(this);
            this._baseApiService = baseApiService;
            this._result = null;
            this._subItems = null;
        }
        ItemsService.prototype.getSubItems = function (id) {
            if (id === void 0) { id = null; }
            console.log("ItemsService.getSubItems()");
            console.log(this);
            var subAddress = "api/items/getSubItems/" + id;
            this._subItems = this._baseApiService.read(subAddress, null);
            return this._subItems;
        };
        ItemsService.prototype.addItem = function (param) {
            if (param === void 0) { param = { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null }; }
            console.log("ItemsService.addItem()");
            console.log(this);
            var subAddress = "api/items/addItem";
            this._result = this._baseApiService.modify(subAddress, param);
            return this._result;
        };
        ItemsService.prototype.editItem = function (param) {
            if (param === void 0) { param = { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null }; }
            console.log("ItemsService.editItem()");
            console.log(this);
            var subAddress = "api/items/editItem";
            this._result = this._baseApiService.modify(subAddress, param);
            return this._result;
        };
        ItemsService.prototype.deleteItem = function (id, param) {
            if (id === void 0) { id = -1; }
            if (param === void 0) { param = { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null }; }
            console.log("ItemsService.deleteItem()");
            console.log(this);
            var subAddress = "api/items/deleteItem/" + id;
            this._result = this._baseApiService.modify(subAddress, param);
            return this._result;
        };
        ItemsService.prototype.flushAndDeleteItem = function (id, param) {
            if (id === void 0) { id = -1; }
            if (param === void 0) { param = { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null }; }
            console.log("ItemsService.deleteItem()");
            console.log(this);
            var subAddress = "api/items/flushAndDeleteItem/" + id;
            this._result = this._baseApiService.modify(subAddress, param);
            return this._result;
        };
        ItemsService.$inject = ["baseApiService"];
        return ItemsService;
    }());
    app.ItemsService = ItemsService;
    angular.module("main").service("itemsService", ItemsService);
})(app || (app = {}));
//# sourceMappingURL=itemsService.js.map