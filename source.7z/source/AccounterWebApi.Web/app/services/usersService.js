var app;
(function (app) {
    //is singleton
    //should contain business logic, data
    var UsersService = (function () {
        function UsersService($q, baseApiService) {
            console.log("UsersService.constructor()");
            console.log(this);
            this._baseApiService = baseApiService;
            this._$q = $q;
            this._result = null;
            this._users = null;
        }
        UsersService.prototype.getUsers = function () {
            console.log("UsersService.getUsers()");
            console.log(this);
            var subAddress = "api/users/getUsers";
            var defer = this._$q.defer();
            this._users = this._baseApiService.read(subAddress, null);
            return this._users;
        };
        UsersService.prototype.addUser = function (param) {
            if (param === void 0) { param = { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" }; }
            console.log("UsersService.addUser()");
            console.log(this);
            var subAddress = "api/users/addUser";
            this._result = this._baseApiService.modify(subAddress, param);
            return this._result;
        };
        UsersService.prototype.editUser = function (param) {
            if (param === void 0) { param = { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" }; }
            console.log("UsersService.editUser()");
            console.log(this);
            var subAddress = "api/users/editUser";
            this._result = this._baseApiService.modify(subAddress, param);
            return this._result;
        };
        UsersService.prototype.deleteUser = function (id, param) {
            if (id === void 0) { id = -1; }
            if (param === void 0) { param = { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" }; }
            console.log("UsersService.deleteUser()");
            console.log(this);
            var subAddress = "api/users/deleteUser/" + id;
            this._result = this._baseApiService.modify(subAddress, param);
            return this._result;
        };
        UsersService.$inject = ["$q", "baseApiService"];
        return UsersService;
    }());
    app.UsersService = UsersService;
    angular.module("main").service("usersService", UsersService);
})(app || (app = {}));
//# sourceMappingURL=usersService.js.map