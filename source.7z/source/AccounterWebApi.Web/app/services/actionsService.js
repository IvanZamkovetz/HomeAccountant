var app;
(function (app) {
    //is singleton
    //should contain business logic, data
    var ActionsService = (function () {
        function ActionsService(baseApiService) {
            console.log("ActionsService.constructor()");
            console.log(this);
            this._baseApiService = baseApiService;
            this._result = null;
            this._actions = null;
        }
        ActionsService.prototype.getActions = function () {
            console.log("ActionsService.getActions()");
            console.log(this);
            var subAddress = "api/actions/getActions";
            this._actions = this._baseApiService.read(subAddress, null);
            return this._actions;
        };
        ActionsService.prototype.addAction = function (param) {
            if (param === void 0) { param = { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09" }; }
            console.log("ActionsService.addAction()");
            console.log(this);
            var subAddress = "api/actions/addAction";
            this._result = this._baseApiService.modify(subAddress, param);
            return this._result;
        };
        ActionsService.prototype.editAction = function (param) {
            if (param === void 0) { param = { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09" }; }
            console.log("ActionsService.editAction()");
            console.log(this);
            var subAddress = "api/actions/editAction";
            this._result = this._baseApiService.modify(subAddress, param);
            return this._result;
        };
        ActionsService.prototype.deleteAction = function (id, param) {
            if (param === void 0) { param = { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09" }; }
            console.log("ActionsService.deleteAction()");
            console.log(this);
            var subAddress = "api/actions/deleteAction/" + id;
            this._result = this._baseApiService.modify(subAddress, param);
            return this._result;
        };
        ActionsService.$inject = ["baseApiService"];
        return ActionsService;
    }());
    app.ActionsService = ActionsService;
    angular.module("main").service("actionsService", ActionsService);
})(app || (app = {}));
//# sourceMappingURL=actionsService.js.map