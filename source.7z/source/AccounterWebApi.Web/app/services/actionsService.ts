﻿module app {
    //is singleton
    //should contain business logic, data
    export class ActionsService {
        private _baseApiService: app.BaseApiService;
        private _actions: ng.IPromise<any>;
        private _result: ng.IPromise<any>;

        static $inject = ["baseApiService"];
        constructor(baseApiService: app.BaseApiService) {
            console.log("ActionsService.constructor()");
            console.log(this);

            this._baseApiService = baseApiService;
            this._result = null;
            this._actions = null;
        }

        getActions(): ng.IPromise<any> {
            console.log("ActionsService.getActions()");
            console.log(this);

            var subAddress = "api/actions/getActions";
            this._actions = this._baseApiService.read(subAddress, null);

            return this._actions;
        }
        addAction(param: any = { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09"}): ng.IPromise<any> {
            console.log("ActionsService.addAction()");
            console.log(this);

            var subAddress = "api/actions/addAction";
            this._result = this._baseApiService.modify(subAddress, param);

            return this._result;
        }
        editAction(param: any = { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09" }): ng.IPromise<any> {
            console.log("ActionsService.editAction()");
            console.log(this);

            var subAddress = "api/actions/editAction";
            this._result = this._baseApiService.modify(subAddress, param);

            return this._result;
        }
        deleteAction(id: number, param: any = { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09" }): ng.IPromise<any> {
            console.log("ActionsService.deleteAction()");
            console.log(this);

            var subAddress = "api/actions/deleteAction/" + id;
            this._result = this._baseApiService.modify(subAddress, param);

            return this._result;
        }
    }

    angular.module("main").service("actionsService", ActionsService);
}   