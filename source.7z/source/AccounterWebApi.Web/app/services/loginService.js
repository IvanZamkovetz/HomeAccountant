var app;
(function (app) {
    //is singleton
    //should contain business logic, data
    var LoginService = (function () {
        function LoginService($q, $rootScope, $http, serializer) {
            console.log("loginService.constructor()");
            console.log(this);
            this._rootScope = $rootScope;
            this._baseAddress = $rootScope.baseAddress;
            this._http = $http;
            this._serializer = serializer;
            this._result = null;
            this._$q = $q;
        }
        LoginService.prototype.logIn = function (param) {
            var _this = this;
            if (param === void 0) { param = { username: "default", password: "default" }; }
            console.log("loginService.logIn()");
            console.log(this);
            var address = this._baseAddress + "oauth/token";
            param.grant_type = "password";
            var config = {
                method: "post",
                url: address,
                data: this._serializer(param),
                headers: { "Content-Type": "application/x-www-form-urlencoded" }
            };
            var defer = this._$q.defer();
            this._result = this._http(config)
                .then(function (success) {
                console.log("loginService.logIn().responseSuccess()");
                console.log("access_token: ");
                console.log(success.data.access_token);
                //set other login data
                _this._rootScope.bearer = success.data.access_token;
                defer.resolve(success.data);
                return defer.promise;
            }, function (error) {
                console.log("loginService.logIn().responseError()");
                defer.reject(error.data.error);
                return defer.promise;
            });
            return this._result;
        };
        LoginService.prototype.logOut = function () {
            this._rootScope.bearer = null;
            //clear other login data
        };
        LoginService.$inject = ["$q", "$rootScope", "$http", "$httpParamSerializer"];
        return LoginService;
    }());
    app.LoginService = LoginService;
    angular.module("main").service("loginService", LoginService);
})(app || (app = {}));
//# sourceMappingURL=loginService.js.map