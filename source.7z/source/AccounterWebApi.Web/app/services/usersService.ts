﻿module app {
    //is singleton
    //should contain business logic, data
    export class UsersService {
        private _baseApiService: app.BaseApiService;

        private _$q: any;
        private _users: ng.IPromise<any>;
        private _result: ng.IPromise<any>;

        static $inject = ["$q", "baseApiService"];
        constructor($q: any, baseApiService: app.BaseApiService) {
            console.log("UsersService.constructor()");
            console.log(this);

            this._baseApiService = baseApiService;
            this._$q = $q;
            this._result = null;
            this._users = null;
        }
        getUsers(): ng.IPromise<any> {
            console.log("UsersService.getUsers()");
            console.log(this);

            var subAddress = "api/users/getUsers";
            var defer = this._$q.defer();
            this._users = this._baseApiService.read(subAddress, null);

            return this._users;
        }
        addUser(param: any = { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" }): ng.IPromise<any> {
            console.log("UsersService.addUser()");
            console.log(this);

            var subAddress = "api/users/addUser";
            this._result = this._baseApiService.modify(subAddress, param);

            return this._result;
        }
        editUser(param: any = { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" }): ng.IPromise<any> {
            console.log("UsersService.editUser()");
            console.log(this);

            var subAddress = "api/users/editUser";
            this._result = this._baseApiService.modify(subAddress, param);

            return this._result;
        }
        deleteUser(id: number = -1, param: any = { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" }): ng.IPromise<any> {
            console.log("UsersService.deleteUser()");
            console.log(this);

            var subAddress = "api/users/deleteUser/" + id;
            this._result = this._baseApiService.modify(subAddress, param);

            return this._result;
        }
    }

    angular.module("main").service("usersService", UsersService);
} 