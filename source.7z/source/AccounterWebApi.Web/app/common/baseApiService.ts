﻿module app {
    //is singleton
    //should contain business logic, data
    export class BaseApiService {
        private _baseAddress: string;

        private _http: ng.IHttpService;
        private _result: ng.IPromise<any>;
        private _$q: any;

        static $inject = ["$q", "$rootScope", "$http"];
        constructor($q, $rootScope: any, $http: ng.IHttpService) {
            console.log("baseApiService.constructor()");
            console.log(this);

            this._baseAddress = $rootScope.baseAddress;
            this._http = $http;
            this._result = null;

            this._result = null;
            this._$q = $q;
        }
        read(subAddress: string, param: any): ng.IPromise<any> {
            console.log("baseApiService.read()");
            console.log(this);

            //buffered query
            //if (this._buffer == null){
            //    console.log("buffer empty");
            var address = this._baseAddress + subAddress;
            var defer = this._$q.defer();
                this._result = this._http.get(address, param)
                    .then((success: any): ng.IPromise<any> => {
                        console.log("baseApiService.read().success()");

                        defer.resolve(success.data);
                        return defer.promise;
                    },
                    (error) => {
                        console.log("baseApiService.read().error()");
                        console.log(error);

                        defer.reject(error.data);
                        return defer.promise;
                    });

                return this._result;
            //}
            //console.log("buffer NOT empty");
            //this._defer.resolve(this._buffer);
            //return this._defer.promise;
        }
        modify(subAddress: string, param: any): ng.IPromise<any> {
            console.log("baseApiService.modify()");
            console.log(this);

            var address = this._baseAddress + subAddress;
            var defer = this._$q.defer();
            this._result = this._http.post(address, param)
                .then((success: any): ng.IPromise<any> => {
                    console.log("baseApiService.read().success()");

                    defer.resolve(success.data);
                    return defer.promise;
                },
                (error) => {
                    console.log("baseApiService.read().error()");
                    console.log(error);

                    defer.reject(error.data);
                    return defer.promise;
                });

            return this._result;
        }
    }

    angular.module("main").service("baseApiService", BaseApiService);
}