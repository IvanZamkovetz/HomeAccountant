﻿module app {
    //register the interceptor as a service
    angular.module("main").factory('bearerInterceptor', ["$rootScope", "$q", function ($rootScope, $q) {
        return {
            // optional method
            'request': function (config) {
                console.log("bearerInterceptor.request()");
                console.log("$rootScope.bearer: ");
                console.log($rootScope.bearer);

                $rootScope.responseError = false;
                $rootScope.responseErrorMessage = "no message";

                if ($rootScope.bearer !== null) {
                    config.headers.Authorization = "Bearer " + $rootScope.bearer;

                    console.log("authorizationRequestHeader: ");
                    console.log(config.headers.Authorization);
                }

                return config;
                //                        try {
                //                            throw config;
                //                        }
                //                        catch (config) {
                //                            throw config;
                //                        }

                //                        console.log("requestHeaders: ");
                // 

            },
            // optional method
            'requestError': function (rejection) {
                console.log("bearerInterceptor.requestError()");

                if (true) {//canRecover(rejection)
                    var responseOrNewPromise = rejection;

                    return responseOrNewPromise;
                }

                //return $q.reject(rejection);
            },
            // optional method
            'response': function (response) {
                console.log("bearerInterceptor.response()");
                console.log("$rootScope.bearer: ");
                console.log($rootScope.bearer);

                //                        console.log("responseHeaders: ");
                //                        console.log(response.headers);

                //set new bearerValue
                if (response.headers.Authorization != null) {
                    console.log("authorizedResponse");
                    //$rootScope.bearer = response.headers.Authorization;

                    console.log("authorizationResponseHeader: ");
                    console.log(response.headers.Authorization);
                }
                return response;
            },
            // optional method
            'responseError': function (rejection) {
                console.log("bearerInterceptor.responseError()");

                if (rejection.status === 401) {
                    //$location.path('/');
                }
                if (true) {//canRecover(rejection)
                    var deferred = $q.defer();

                    //rejection.headers.Bearer = "handledBearer";
                    //var handled = rejection;
                    //handled.data = "data";

                    //get error message
                    $rootScope.responseErrorMessage = rejection.data;
                    $rootScope.responseError = true;

                    deferred.reject(rejection);
                    return deferred.promise;
                }
                //                    rejection.headers.Bearer = "unHandledBearer";
                //                    return $q.reject(rejection);
            }
        };
    }]);
}