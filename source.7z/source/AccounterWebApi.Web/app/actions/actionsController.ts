﻿module app {
    //isn't singleton
    //controller shuldn't manipulate DOM
    //shouldn't contain anything except scope data
    export interface IActionsModel extends ng.IScope {

        actionsController: ActionsController;
    }

    export class ActionsController {
        private _scope: any;
        private _actionsService: app.ActionsService;

        static $inject = ["$scope", "actionsService"];
        constructor($scope: any, actionsService: app.ActionsService) {
            console.log("ActionsController.constructor()");
            console.log(this);

            this._actionsService = actionsService;
            this.scopeInitialize($scope);
        }
        getActions() {
            console.log("ActionsController.getActions()");
            console.log(this);

            this._actionsService.getActions().then((data) => {
                console.log("ActionsController.getActions().success()");
                console.log(this);

                (this._scope.actions as kendo.data.ObservableArray).splice(0, this._scope.actions.length);

                var i = 0;
                for (i = 0; i < data.length; i++) {
                    (this._scope.actions as kendo.data.ObservableArray).push(data[i]);
                }
            },
                (error) => {
                    console.log("ActionsController.getActions().error()");
                    console.log(this);
                });
        }
        addAction(action) {
            this._actionsService.addAction(action);
            this._scope.actions.push(action);
            //impRow.removeClass('k-state-selected');
            
        }
        editAction(action) {
            this._actionsService.editAction(action);
            //impRow.removeClass('k-state-selected');

        }
        deleteAction(action) {
            this._actionsService.deleteAction(action.Id, action);
            //removing from actions
            var i = 0;
            for (i = 0; i < this._scope.actions.length; i++)
            {
                if (this._scope.actions[i].Id === action.Id)
                {
                    this._scope.actions.splice(i, 1);
                }
            }
            //impRow.removeClass('k-state-selected');
        }
        newAction(action)
        {
            this._scope.action = { Id: action.Id, ItemName: action.ItemName, Price: action.Price, Balance: action.Balance, ActionDate: action.ActionDate };
        }
        select(dataItem) {
            this._scope.action = dataItem;
        }
        scopeInitialize($scope) {
            console.log("ActionsController.scopeInitialize()");
            console.log(this);

            this._scope = $scope;
            ActionsController.prototype._scope = $scope;
            this._scope.ActionsController = this;

            $scope.action = null;

            $scope.actions = new kendo.data.ObservableArray([
                { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09" },
                { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09" },
                { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09" },
                { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09" },
                { Id: -1, ItemName: "default", Price: 0, Balance: null, ActionDate: "1945/05/09" },

            ]);

            $scope.gridOptions = {

                height: 300,
                groupable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                selectable: "row",
                columns: [{ field: "Id", title: "Id" },
                    { field: "ActionDate", title: "Action Date" },
                    { field: "ItemName", title: "Item Name" },
                    { field: "Price", title: "Price" },
                    { field: "Balance", title: "Balance" },
                ]
            };
        }
    }
    angular.module("main").controller("actionsController", ActionsController);
} 