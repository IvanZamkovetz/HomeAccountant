﻿module app {
    declare var EventSource: sse.IEventSourceStatic;

    export class MainController
    {
        private _$state: any;
        private _eventSource: sse.IEventSourceStatic;
        private _baseAddress: string;
        private _scope: any;
        private _loginService: app.LoginService;

        static $inject = ["$state", "$rootScope", "$scope", "loginService"]; 
        constructor($state, $rootScope: any, $scope: any, loginService: app.LoginService)
        {
            console.log("MainController.constructor()");
            console.log(this);

            this._$state = $state;
            this._baseAddress = $rootScope.baseAddress;
            this._loginService = loginService;

            this._scope = $scope;
            MainController.prototype._scope = $scope;
            MainController.prototype._$state = this._$state;
            $scope.MainController = this;

            this._scope.sseData = null;
            ($scope as ng.IScope).$on("loginSucceeded", this.loginSucceeded);
        }
        //listeners
        loginSucceeded(e: ng.IAngularEvent, items: any) {
            console.log("MainController.loginSucceeded()");
            console.log(this);

            MainController.prototype.scopeInit();
            MainController.prototype._$state.go("home");
        }
        itemParametersChanged(e: ng.IAngularEvent, itemParam: any)
        {
            console.log("MainController.itemParametersChanged()");
            console.log(this);

            this._scope.itemParam = itemParam;
        }

        //events
        logOut()
        {
            console.log("MainController.logOut()");
            console.log(this);

            //denie treeView loading data
            //flush Actions Diagramm data
            this._scope.isLogin = false;
            (this._scope as ng.IScope).$broadcast("logout", null);

            this._loginService.logOut();
            this._$state.go("login");
        }

        //common
        scopeInit()
        {
            console.log("MainController.scopeInit()");
            console.log(this);

            //load treeView dataSource
            //load Actions/Schedule dataSource
            (this._scope as ng.IScope).$broadcast("login", null);
            this.createChart();
            (this._scope as ng.IScope).$on("itemParametersChanged", this.itemParametersChanged);

            this._scope.isLogin = true;
        }
        beginAcceptSse(): void {
            console.log("MainController.beginAcceptSse()");
            console.log(this);

            if (typeof (EventSource) !== undefined) {//
                // Yes! Server-sent events support!
                var sseAddress = this._baseAddress + "api/test/get";
                this._eventSource = new EventSource(sseAddress, null);

                this._eventSource.onmessage = function (event) {
                    console.log("headerController.EventSource.OnMessage()");

                    MainController.prototype._scope.sseData = event.data;
                    MainController.prototype._scope.$apply();
                };
                this._eventSource.onerror = function () {
                    console.log("headerController.EventSource.OnError()");
                    alert("sseError");
                };
            }
            else {
                // Sorry! No server-sent events support..
                alert('SSE not supported by browser.');
            }
        }
        createChart(subItems: any[] = null) {
            console.log("foodDiagramm.createChart()");

            var subItems: any[] = [{ Name: "someAction1", UnitsNumber: 1 },
                { Name: "someAction2", UnitsNumber: 2 },
                { Name: "someAction3", UnitsNumber: 3 }];

            var chartInstance = new Highcharts.Chart({
                //point click event
                /*
                mark point value as fixed
                save it's value
                */
                chart: {
                    type: 'bar',
                    renderTo: 'balanceChartContainer',
                    animation: false,

                    events: {
                        load: function () {
                            setInterval(function () {

                            }, 5000);
                        }
                    }
                },

                title: {
                    text: 'Balance Diagramm'
                },

                xAxis: {
                    categories: function () {
                        var categories = new Array();

                        $.each(subItems, function (index, product) {
                            categories.push(product.Name);
                        })

                        return categories;
                    } ()
                },

                plotOptions: {
                    series: {
                        point: {
                            events: {

                                //drag: function (e) {
                                //    // Returning false stops the drag and drops. Example:
                                //    /*
                                //    if (e.newY > 300) {
                                //        this.y = 300;
                                //        return false;
                                //    }
                                //    */

                                //    $('#drag').html(
                                //        'Dragging <b>' + this.series.name + '</b>, <b>' + this.category + '</b> to <b>' + Highcharts.numberFormat(e.y, 2) + '</b>');

                                //},
                                //drop: function () {
                                //    /*
                                //    if point value is fixed, return new value to old value
                                //    */
                                //    var y = this.y;
                                //    var index = this.series.data.indexOf(this);

                                //    this.calculate(index, y, this.series.data);

                                //    $('#drop').html(
                                //        'In <b>' + this.series.name + '</b>, <b>' + this.category + '</b> was set to <b>' + Highcharts.numberFormat(this.y, 2) + '</b>');
                                //}
                            }
                        },
                        stickyTracking: false
                    },
                    column: {
                        stacking: 'normal'
                    },
                    line: {
                        cursor: 'ns-resize'
                    }
                },

                tooltip: {
                    //yDecimals: 2
                },

                series: [{
                    data: function () {
                        var data = new Array();

                        $.each(subItems, function (index, product) {
                            data.push(product.UnitsNumber);
                        })

                        return data;
                    } (),
                    //draggableY: true,
                    //dragMinY: 0,
                    type: 'column',
                    //minPointLength: 2
                }]

            });
        }
    }

    angular.module("main").controller("mainController", MainController);
}