var app;
(function (app) {
    var ItemsController = (function () {
        function ItemsController($stateParams, $scope, itemsService) {
            console.log("ItemsController.constructor()");
            console.log(this);
            console.log("$stateParams: ");
            console.log($stateParams);
            //retrive it from stateProvider
            this._parentId = $stateParams.Id;
            this._itemsService = itemsService;
            this.itemPeriod = 0;
            this.itemPrice = 0;
            this.scopeInitialize($scope);
        }
        ItemsController.prototype.getSubItems = function () {
            var _this = this;
            console.log("ItemsController.getSubItems()");
            console.log(this);
            this._itemsService.getSubItems(this._scope.parentId).then(function (data) {
                console.log("ItemsController.getSubItems().success()");
                console.log(_this);
                _this.bindSubItems(data);
            }, function (error) {
                console.log("ItemsController.getSubItems().error()");
                console.log(_this);
            });
        };
        ItemsController.prototype.addItem = function (item) {
            this._itemsService.addItem(item);
            this._scope.items.push(item);
            //impRow.removeClass('k-state-selected');
        };
        ItemsController.prototype.editItem = function (item) {
            this._itemsService.editItem(item);
            //impRow.removeClass('k-state-selected');
        };
        ItemsController.prototype.deleteItem = function (item) {
            this._itemsService.deleteItem(item.Id, item);
            //removing from items
            var i = 0;
            for (i = 0; i < this._scope.items.length; i++) {
                if (this._scope.items[i].Id === item.Id) {
                    this._scope.items.splice(i, 1);
                }
            }
            //impRow.removeClass('k-state-selected');
        };
        ItemsController.prototype.flushAndDeleteItem = function () {
            this._itemsService.flushAndDeleteItem(this._scope.parentId, null);
            //removing from items
            this._scope.items.splice(0, this._scope.items.length);
            //impRow.removeClass('k-state-selected');
        };
        //events
        ItemsController.prototype.newItem = function (item) {
            this._scope.item = { Id: item.Id, Name: item.Name, PricePerUnit: item.PricePerUnit, UnitsNumber: item.UnitsNumber, TotalPrice: item.TotalPrice, ParentId: item.ParentId };
        };
        ItemsController.prototype.select = function (dataItem) {
            this._scope.item = dataItem;
        };
        ItemsController.prototype.changeItemParameters = function (itemId, itemPrice, itemPeriod) {
            var itemParam = {
                itemId: itemId,
                itemPrice: itemPrice,
                itemPeriod: itemPeriod
            };
            this._scope.$emit("itemParametersChanged", itemParam);
        };
        //listeners
        ItemsController.prototype._listener = function (e, items) {
            console.log("itemsController._listener()");
            console.log(this);
            ItemsController.prototype._scope.items = new Object(items);
            //scope.apply
        };
        //common
        ItemsController.prototype.scopeInitialize = function ($scope) {
            console.log("ItemsController.scopeInitialize()");
            console.log(this);
            this._scope = $scope;
            ItemsController.prototype._scope = $scope;
            this._scope.ItemsController = this;
            this._scope.itemPeriod = 0;
            this._scope.itemPrice = 0;
            this._scope.$on("itemsUpdated", this._listener);
            $scope.parentId = this._parentId;
            $scope.item = null;
            $scope.items = new kendo.data.ObservableArray([
                { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null },
                { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null },
                { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null },
                { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null },
                { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null },
            ]);
            $scope.gridOptions = {
                height: 300,
                groupable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                selectable: "row",
                columns: [{ field: "Id", title: "Id" },
                    { field: "Name", title: "User Name" },
                    { field: "PricePerUnit", title: "Price Per Unit" },
                    { field: "UnitsNumber", title: "Units Number" },
                    { field: "TotalPrice", title: "Total Price" },
                    { field: "ParentId", title: "Parent Id" },
                ]
            };
        };
        ItemsController.prototype.bindSubItems = function (data) {
            console.log("itemsController.bindSubItems()");
            console.log(this);
            this._scope.items.splice(0, this._scope.items.length);
            var i = 0;
            for (i = 0; i < data.length; i++) {
                this._scope.items.push(data[i]);
            }
            this._scope.itemPrice = 0;
            this.itemPrice = 0;
            var i = 0;
            for (i = 0; i < this._scope.items.length; i++) {
                this._scope.itemPrice += this._scope.items[i].TotalPrice;
                this.itemPrice += this._scope.items[i].TotalPrice;
            }
            ;
            this._scope.$broadcast("subItemsLoaded", this._scope.items);
        };
        ItemsController.$inject = ["$stateParams", "$scope", "itemsService"];
        return ItemsController;
    }());
    app.ItemsController = ItemsController;
    angular.module("main").controller("itemsController", ItemsController);
})(app || (app = {}));
//# sourceMappingURL=itemsController.js.map