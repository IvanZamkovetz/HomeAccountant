﻿module app {
    //isn't singleton
    //controller shuldn't manipulate DOM
    //shouldn't contain anything except scope data
    export interface IItemsModel extends ng.IScope {

        items: any;
        itemPrice: number;
        itemPeriod: number;

        itemsController: ItemsController;
    }

    export class ItemsController {
        private _scope: any;
        private _itemsService: app.ItemsService;
        private _parentId: number;
        public itemPrice: number;
        public itemPeriod: number;

        static $inject = ["$stateParams", "$scope", "itemsService"];
        constructor($stateParams: any, $scope: any, itemsService: app.ItemsService) {
            console.log("ItemsController.constructor()");
            console.log(this);
            console.log("$stateParams: ");
            console.log($stateParams);

            //retrive it from stateProvider
            this._parentId = $stateParams.Id;
            this._itemsService = itemsService;
            this.itemPeriod = 0;
            this.itemPrice = 0;

            this.scopeInitialize($scope);
        }
        getSubItems() {
            console.log("ItemsController.getSubItems()");
            console.log(this);

            this._itemsService.getSubItems(this._scope.parentId).then((data) => {
                console.log("ItemsController.getSubItems().success()");
                console.log(this);

                this.bindSubItems(data);

            },
                (error) => {
                    console.log("ItemsController.getSubItems().error()");
                    console.log(this);
                });
        }
        addItem(item) {
            this._itemsService.addItem(item);
            this._scope.items.push(item);
            //impRow.removeClass('k-state-selected');
            
        }
        editItem(item) {
            this._itemsService.editItem(item);
            //impRow.removeClass('k-state-selected');

        }
        deleteItem(item) {
            this._itemsService.deleteItem(item.Id, item);
            //removing from items
            var i = 0;
            for (i = 0; i < this._scope.items.length; i++)
            {
                if (this._scope.items[i].Id === item.Id)
                {
                    this._scope.items.splice(i, 1);
                }
            }
            //impRow.removeClass('k-state-selected');
        }
        flushAndDeleteItem()
        {
            this._itemsService.flushAndDeleteItem(this._scope.parentId, null);
            //removing from items
            (this._scope.items as kendo.data.ObservableArray).splice(0, this._scope.items.length);

            //impRow.removeClass('k-state-selected');
        }

        //events
        newItem(item)
        {
            this._scope.item = { Id: item.Id, Name: item.Name, PricePerUnit: item.PricePerUnit, UnitsNumber: item.UnitsNumber, TotalPrice: item.TotalPrice, ParentId: item.ParentId };
        }
        select(dataItem) {
            this._scope.item = dataItem;
        }
        changeItemParameters(itemId, itemPrice, itemPeriod) {
            var itemParam = {
                itemId: itemId,
                itemPrice: itemPrice,
                itemPeriod: itemPeriod
            };
            (this._scope as ng.IScope).$emit("itemParametersChanged", itemParam);
        }

        //listeners
        private _listener(e: ng.IAngularEvent, items: any): any {
            console.log("itemsController._listener()");
            console.log(this);

            ItemsController.prototype._scope.items = new Object(items);
            //scope.apply
        }

        //common
        scopeInitialize($scope) {
            console.log("ItemsController.scopeInitialize()");
            console.log(this);

            this._scope = $scope;
            ItemsController.prototype._scope = $scope;
            this._scope.ItemsController = this;

            this._scope.itemPeriod = 0;
            this._scope.itemPrice = 0;
            (this._scope as ng.IScope).$on("itemsUpdated", this._listener);

            $scope.parentId = this._parentId;
            $scope.item = null;

            $scope.items = new kendo.data.ObservableArray([
                { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null },
                { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null },
                { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null },
                { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null },
                { Id: -1, Name: "default", PricePerUnit: 1, UnitsNumber: 1, TotalPrice: null, ParentId: null },

            ]);

            $scope.gridOptions = {

                height: 300,
                groupable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                selectable: "row",
                columns: [{ field: "Id", title: "Id" },
                    { field: "Name", title: "User Name" },
                    { field: "PricePerUnit", title: "Price Per Unit" },
                    { field: "UnitsNumber", title: "Units Number" },
                    { field: "TotalPrice", title: "Total Price" },
                    { field: "ParentId", title: "Parent Id" },

                ]
            };
        }
        bindSubItems(data): void {
            console.log("itemsController.bindSubItems()");
            console.log(this);

            (this._scope.items as kendo.data.ObservableArray).splice(0, this._scope.items.length);

            var i = 0;
            for (i = 0; i < data.length; i++) {
                (this._scope.items as kendo.data.ObservableArray).push(data[i]);
            }

            this._scope.itemPrice = 0;
            this.itemPrice = 0;
            var i = 0;
            for (i = 0; i < this._scope.items.length; i++) {
                this._scope.itemPrice += this._scope.items[i].TotalPrice;
                this.itemPrice += this._scope.items[i].TotalPrice;
            };
            this._scope.$broadcast("subItemsLoaded", this._scope.items);
        }

    }
    angular.module("main").controller("itemsController", ItemsController);
} 