﻿module app {
    //directive have to manipulate DOM
    export class ItemDiagramm implements ng.IDirective {
        private _scope;

        public templateUrl: string | Function;
        public link: ng.IDirectiveLinkFn | ng.IDirectivePrePost;
        public scope: boolean | Object;

        constructor() {
            console.log("itemDiagramm.constructor()");
            console.log(this);

            this.templateUrl = "itemDiagramm/itemDiagramm.html"
            this.link = this.linkMethod;
            this.scope = {};

        }

        public linkMethod($scope, element: any): void {
            console.log("itemDiagramm.link()");
            console.log(this);

            ($scope as ng.IScope).$on("subItemsLoaded", (e: ng.IAngularEvent, subItems: any): any => {
                console.log("itemDiagramm.subItemsLoaded()");
                console.log($scope);
                console.log("itemDiagramm.subItems: ");
                console.log(subItems);

                //?object passed bu value
                $scope.subItems = subItems;
                ItemDiagramm.prototype.createChart($scope);
            });
            $scope.updateItems = (): void => {
                console.log("itemDiagramm.inlineEmitter()");
                console.log($scope);

                $scope.$emit("subItemsUpdated", $scope.subItems);
            };
            $scope.subItems = "please wait ...";

        }
        private _listener(e: ng.IAngularEvent, subItems: any[]): any {
            console.log("itemDiagramm._listener()");
            console.log(this);

            ItemDiagramm.prototype._scope.subItems = new Object(subItems);

        }
        private _changePeroidPrice() {
            ItemDiagramm.prototype._scope.data = {
                ItemId: 0,
                ItemPeriod: 12,
                ItemPrice: 12
            };
            (ItemDiagramm.prototype._scope as ng.IScope).$emit("itemPeriodPriceUpdated", ItemDiagramm.prototype._scope.data);

        }
        createChart($scope: any) {
            console.log("foodDiagramm.createChart()");

            var $currentScope = $scope;
            var subItems = $scope.subItems;

            var chartInstance = new Highcharts.Chart({
                //point click event
                /*
                mark point value as fixed
                save it's value
                */
                chart: {
                    //type: 'bar',
                    renderTo: 'container',
                    animation: false,

                    events: {
                        load: function () {
                            setInterval(function () {

                            }, 5000);
                        }
                    }
                },

                title: {
                    text: 'Items Diagramm'
                },

                xAxis: {
                    categories: function () {
                        var categories = new Array();

                        $.each(subItems, function (index, product) {
                            categories.push(product.Name);
                        })

                        return categories;
                    } ()
                },

                plotOptions: {
                    series: {
                        point: {
                            events: {

                                drag: function (e) {
                                    // Returning false stops the drag and drops. Example:
                                    /*
                                    if (e.newY > 300) {
                                        this.y = 300;
                                        return false;
                                    }
                                    */

                                    $('#drag').html(
                                        'Dragging <b>' + this.series.name + '</b>, <b>' + this.category + '</b> to <b>' + Highcharts.numberFormat(e.y, 2) + '</b>');

                                },
                                drop: function () {
                                    /*
                                    if point value is fixed, return new value to old value
                                    */
                                    var y = this.y;
                                    var index = this.series.data.indexOf(this);

                                    ItemDiagramm.prototype.calculate($currentScope, index, y, this.series.data);

                                    $('#drop').html(
                                        'In <b>' + this.series.name + '</b>, <b>' + this.category + '</b> was set to <b>' + Highcharts.numberFormat(this.y, 2) + '</b>');
                                }
                            }
                        },
                        stickyTracking: false
                    },
                    column: {
                        stacking: 'normal'
                    },
                    line: {
                        cursor: 'ns-resize'
                    }
                },

                tooltip: {
                    //yDecimals: 2
                },

                series: [{
                    data: function () {
                        var data = new Array();

                        $.each(subItems, function (index, product) {
                            data.push(product.UnitsNumber);
                        })

                        return data;
                    } (),
                    draggableY: true,
                    dragMinY: 0,
                    type: 'column',
                    minPointLength: 2
                }]

            });
        }
        calculate($currentScope: any, index, y, data) {
            //relocate subItems
            var subItems: any[];
            subItems = $currentScope.subItems;

            var productsQuantity = subItems.length - 1;
            var deltaPrice = subItems[index].PricePerUnit * (subItems[index].UnitsNumber - y);
            subItems[index].UnitsNumber = y;

            var productQuantity = 0;

            $.each(data, function (i, point) {
                //if point value is fiexd, continue
                if (i !== index) {
                    productQuantity = deltaPrice / (productsQuantity * subItems[i].PricePerUnit);
                    subItems[i].UnitsNumber += productQuantity;
                    point.update(subItems[i].UnitsNumber, true, true);
                }
            });
        }
    }

    function directiveFactory(): ng.IDirectiveFactory {
        console.log("directiveFactory()");

        var factory: ng.IDirectiveFactory = function factory(): any {
            console.log("factory()");

            return new ItemDiagramm();
        };
        factory.$inject = [];

        return factory;
    }

    angular.module("main").directive("itemDiagramm", directiveFactory());//
}
