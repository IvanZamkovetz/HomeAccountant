var app;
(function (app) {
    //directive have to manipulate DOM
    var ItemDiagramm = (function () {
        function ItemDiagramm() {
            console.log("itemDiagramm.constructor()");
            console.log(this);
            this.templateUrl = "itemDiagramm/itemDiagramm.html";
            this.link = this.linkMethod;
            this.scope = {};
        }
        ItemDiagramm.prototype.linkMethod = function ($scope, element) {
            console.log("itemDiagramm.link()");
            console.log(this);
            $scope.$on("subItemsLoaded", function (e, subItems) {
                console.log("itemDiagramm.subItemsLoaded()");
                console.log($scope);
                console.log("itemDiagramm.subItems: ");
                console.log(subItems);
                //?object passed bu value
                $scope.subItems = subItems;
                ItemDiagramm.prototype.createChart($scope);
            });
            $scope.updateItems = function () {
                console.log("itemDiagramm.inlineEmitter()");
                console.log($scope);
                $scope.$emit("subItemsUpdated", $scope.subItems);
            };
            $scope.subItems = "please wait ...";
        };
        ItemDiagramm.prototype._listener = function (e, subItems) {
            console.log("itemDiagramm._listener()");
            console.log(this);
            ItemDiagramm.prototype._scope.subItems = new Object(subItems);
        };
        ItemDiagramm.prototype._changePeroidPrice = function () {
            ItemDiagramm.prototype._scope.data = {
                ItemId: 0,
                ItemPeriod: 12,
                ItemPrice: 12
            };
            ItemDiagramm.prototype._scope.$emit("itemPeriodPriceUpdated", ItemDiagramm.prototype._scope.data);
        };
        ItemDiagramm.prototype.createChart = function ($scope) {
            console.log("foodDiagramm.createChart()");
            var $currentScope = $scope;
            var subItems = $scope.subItems;
            var chartInstance = new Highcharts.Chart({
                //point click event
                /*
                mark point value as fixed
                save it's value
                */
                chart: {
                    //type: 'bar',
                    renderTo: 'container',
                    animation: false,
                    events: {
                        load: function () {
                            setInterval(function () {
                            }, 5000);
                        }
                    }
                },
                title: {
                    text: 'Items Diagramm'
                },
                xAxis: {
                    categories: function () {
                        var categories = new Array();
                        $.each(subItems, function (index, product) {
                            categories.push(product.Name);
                        });
                        return categories;
                    }()
                },
                plotOptions: {
                    series: {
                        point: {
                            events: {
                                drag: function (e) {
                                    // Returning false stops the drag and drops. Example:
                                    /*
                                    if (e.newY > 300) {
                                        this.y = 300;
                                        return false;
                                    }
                                    */
                                    $('#drag').html('Dragging <b>' + this.series.name + '</b>, <b>' + this.category + '</b> to <b>' + Highcharts.numberFormat(e.y, 2) + '</b>');
                                },
                                drop: function () {
                                    /*
                                    if point value is fixed, return new value to old value
                                    */
                                    var y = this.y;
                                    var index = this.series.data.indexOf(this);
                                    ItemDiagramm.prototype.calculate($currentScope, index, y, this.series.data);
                                    $('#drop').html('In <b>' + this.series.name + '</b>, <b>' + this.category + '</b> was set to <b>' + Highcharts.numberFormat(this.y, 2) + '</b>');
                                }
                            }
                        },
                        stickyTracking: false
                    },
                    column: {
                        stacking: 'normal'
                    },
                    line: {
                        cursor: 'ns-resize'
                    }
                },
                tooltip: {},
                series: [{
                        data: function () {
                            var data = new Array();
                            $.each(subItems, function (index, product) {
                                data.push(product.UnitsNumber);
                            });
                            return data;
                        }(),
                        draggableY: true,
                        dragMinY: 0,
                        type: 'column',
                        minPointLength: 2
                    }]
            });
        };
        ItemDiagramm.prototype.calculate = function ($currentScope, index, y, data) {
            //relocate subItems
            var subItems;
            subItems = $currentScope.subItems;
            var productsQuantity = subItems.length - 1;
            var deltaPrice = subItems[index].PricePerUnit * (subItems[index].UnitsNumber - y);
            subItems[index].UnitsNumber = y;
            var productQuantity = 0;
            $.each(data, function (i, point) {
                //if point value is fiexd, continue
                if (i !== index) {
                    productQuantity = deltaPrice / (productsQuantity * subItems[i].PricePerUnit);
                    subItems[i].UnitsNumber += productQuantity;
                    point.update(subItems[i].UnitsNumber, true, true);
                }
            });
        };
        return ItemDiagramm;
    }());
    app.ItemDiagramm = ItemDiagramm;
    function directiveFactory() {
        console.log("directiveFactory()");
        var factory = function factory() {
            console.log("factory()");
            return new ItemDiagramm();
        };
        factory.$inject = [];
        return factory;
    }
    angular.module("main").directive("itemDiagramm", directiveFactory()); //
})(app || (app = {}));
//# sourceMappingURL=itemDiagramm.js.map