var app;
(function (app) {
    var HomeController = (function () {
        function HomeController($scope) {
            this._$scope = $scope;
            this._$scope.HomeController = this;
            this._data = 8;
        }
        return HomeController;
    }());
    app.HomeController = HomeController;
    angular.module("main").controller("homeController", HomeController);
})(app || (app = {}));
//# sourceMappingURL=homeController.js.map