﻿module app {
    export class HomeController
    {
        private _data: any;
        private _$scope: any;

        constructor($scope)
        {
            this._$scope = $scope;
            this._$scope.HomeController = this;

            this._data = 8;
        }

    }
    angular.module("main").controller("homeController", HomeController);
} 