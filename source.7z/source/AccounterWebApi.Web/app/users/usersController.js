var app;
(function (app) {
    var UsersController = (function () {
        function UsersController($scope, usersService) {
            console.log("UsersController.constructor()");
            console.log(this);
            this._usersService = usersService;
            this.scopeInitialize($scope);
        }
        UsersController.prototype.getUsers = function () {
            var _this = this;
            console.log("UsersController.getUsers()");
            console.log(this);
            this._usersService.getUsers().then(function (data) {
                console.log("UsersController.getUsers().success()");
                console.log(_this);
                _this._scope.users.splice(0, _this._scope.users.length);
                var i = 0;
                for (i = 0; i < data.length; i++) {
                    _this._scope.users.push(data[i]);
                }
            }, function (error) {
                console.log("UsersController.getUsers().error()");
                console.log(_this);
            });
        };
        UsersController.prototype.addUser = function (user) {
            this._usersService.addUser(user);
            this._scope.users.push(user);
            //impRow.removeClass('k-state-selected');
        };
        UsersController.prototype.editUser = function (user) {
            this._usersService.editUser(user);
            //impRow.removeClass('k-state-selected');
        };
        UsersController.prototype.deleteUser = function (user) {
            this._usersService.deleteUser(user.Id, user);
            //removing from users
            var i = 0;
            for (i = 0; i < this._scope.users.length; i++) {
                if (this._scope.users[i].Id === user.Id) {
                    this._scope.users.splice(i, 1);
                }
            }
            //impRow.removeClass('k-state-selected');
        };
        UsersController.prototype.newUser = function (user) {
            this._scope.user = { Id: user.Id, UserName: user.UserName, LoginName: user.LoginName, LoginPassword: user.LoginPassword };
        };
        UsersController.prototype.select = function (dataItem) {
            this._scope.user = dataItem;
        };
        UsersController.prototype.scopeInitialize = function ($scope) {
            console.log("UsersController.scopeInitialize()");
            console.log(this);
            this._scope = $scope;
            UsersController.prototype._scope = $scope;
            this._scope.UsersController = this;
            $scope.user = null;
            $scope.users = new kendo.data.ObservableArray([
                { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" },
                { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" },
                { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" },
                { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" },
                { Id: -1, UserName: "default", LoginName: "default", LoginPassword: "default" }
            ]);
            $scope.gridOptions = {
                height: 300,
                groupable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                selectable: "row",
                columns: [{ field: "Id", title: "Id" },
                    { field: "UserName", title: "User Name" },
                    { field: "LoginName", title: "Login Name" },
                    { field: "LoginPassword", title: "Login Password" }
                ]
            };
        };
        UsersController.$inject = ["$scope", "usersService"];
        return UsersController;
    }());
    app.UsersController = UsersController;
    angular.module("main").controller("usersController", UsersController);
})(app || (app = {}));
//# sourceMappingURL=usersController.js.map