var app;
(function (app) {
    var HeaderController = (function () {
        function HeaderController($rootScope, $scope, baseApiService) {
            console.log("headerController.constructor()");
            console.log(this);
            this._baseAddress = $rootScope.baseAddress;
            this._scope = $scope;
            HeaderController.prototype._scope = $scope;
            this._scope.headerController = this;
            this._repository = baseApiService;
            this._scope.sseData = null;
        }
        HeaderController.prototype.beginAcceptSse = function () {
            console.log("headerController.beginAcceptSse()");
            if (typeof (EventSource) !== "undefined") {
                // Yes! Server-sent events support!
                var sseAddress = this._baseAddress + "api/test";
                this._eventSource = new EventSource("sseAddress", null);
                this._eventSource.onmessage = function (event) {
                    console.log("headerController.EventSource.OnMessage()");
                    HeaderController.prototype._scope.sseData = event.data;
                    HeaderController.prototype._scope.$apply();
                };
                this._eventSource.onerror = function () {
                    console.log("headerController.EventSource.OnError()");
                    alert("sseError");
                };
            }
            else {
                // Sorry! No server-sent events support..
                alert('SSE not supported by browser.');
            }
        };
        HeaderController.$inject = ["$scope", "$rootScope", "baseApiService"];
        return HeaderController;
    }());
    app.HeaderController = HeaderController;
    angular.module("main").controller("headerController", HeaderController);
})(app || (app = {}));
//# sourceMappingURL=headerController.js.map