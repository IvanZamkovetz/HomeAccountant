﻿module app {
    declare var EventSource: sse.IEventSourceStatic;

    //isn't singleton
    //controller shuldn't manipulate DOM
    //shouldn't contain anything except scope data
    export interface IHeaderModel extends ng.IScope {

        headerController: HeaderController;
    }

    export class HeaderController {
        private _eventSource: sse.IEventSourceStatic;
        private _baseAddress;
        private _scope: any;
        private _repository: any;

        static $inject = ["$scope", "$rootScope", "baseApiService"];
        constructor($rootScope: any, $scope: any, baseApiService: app.BaseApiService) {
            console.log("headerController.constructor()");
            console.log(this);

            this._baseAddress = $rootScope.baseAddress;
            this._scope = $scope;
            HeaderController.prototype._scope = $scope;
            this._scope.headerController = this;

            this._repository = baseApiService;
            this._scope.sseData = null;

        }
        beginAcceptSse(): void {
            console.log("headerController.beginAcceptSse()");

            if (typeof (EventSource) !== "undefined") {//
                // Yes! Server-sent events support!
                var sseAddress = this._baseAddress + "api/test";
                this._eventSource = new EventSource("sseAddress", null);

                this._eventSource.onmessage = function (event) {
                    console.log("headerController.EventSource.OnMessage()");

                    HeaderController.prototype._scope.sseData = event.data;
                    HeaderController.prototype._scope.$apply();
                };
                this._eventSource.onerror = function () {
                    console.log("headerController.EventSource.OnError()");
                    alert("sseError");
                };
            }
            else {
                // Sorry! No server-sent events support..
                alert('SSE not supported by browser.');
            }
        }
    }
    angular.module("main").controller("headerController", HeaderController);
} 