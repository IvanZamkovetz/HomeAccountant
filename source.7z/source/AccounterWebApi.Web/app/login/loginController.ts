﻿module app {
    export class LoginController {
        private _scope: any;
        private _loginService: app.LoginService;

        static $inject = ["$scope", "loginService"];
        constructor($scope: any, loginService: app.LoginService) {
            console.log("LoginController.constructor()");
            console.log(this);

            this._loginService = loginService;

            this._scope = $scope;
            LoginController.prototype._scope = $scope;
            $scope.LoginController = this;

            this._scope.loginErrorMessage = "no login error message";
        }
        logIn() {
            console.log("LoginController.logIn()");
            console.log(this);

            var credentials = {
                "username": this._scope.loginName,
                "password": this._scope.loginPassword
            };
            this._loginService.logIn(credentials).then((data) => {
                console.log("LoginController.logIn().success()");

                this._scope.loginErrorMessage = "no login error message";
                this._scope.$emit("loginSucceeded", null);
            },
                (error) => {
                    console.log("LoginController.logIn().error()");
                    console.log(this);

                    this._scope.loginErrorMessage = error;

                });
        };
    }

    angular.module("main").controller("loginController", LoginController);
} 