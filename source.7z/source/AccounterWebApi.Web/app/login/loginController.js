var app;
(function (app) {
    var LoginController = (function () {
        function LoginController($scope, loginService) {
            console.log("LoginController.constructor()");
            console.log(this);
            this._loginService = loginService;
            this._scope = $scope;
            LoginController.prototype._scope = $scope;
            $scope.LoginController = this;
            this._scope.loginErrorMessage = "no login error message";
        }
        LoginController.prototype.logIn = function () {
            var _this = this;
            console.log("LoginController.logIn()");
            console.log(this);
            var credentials = {
                "username": this._scope.loginName,
                "password": this._scope.loginPassword
            };
            this._loginService.logIn(credentials).then(function (data) {
                console.log("LoginController.logIn().success()");
                _this._scope.loginErrorMessage = "no login error message";
                _this._scope.$emit("loginSucceeded", null);
            }, function (error) {
                console.log("LoginController.logIn().error()");
                console.log(_this);
                _this._scope.loginErrorMessage = error;
            });
        };
        ;
        LoginController.$inject = ["$scope", "loginService"];
        return LoginController;
    }());
    app.LoginController = LoginController;
    angular.module("main").controller("loginController", LoginController);
})(app || (app = {}));
//# sourceMappingURL=loginController.js.map