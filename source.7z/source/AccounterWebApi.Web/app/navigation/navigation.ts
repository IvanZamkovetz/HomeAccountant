﻿module app {
    //directive have to manipulate DOM
    export class Navigation implements ng.IDirective {
        private _itemsService: app.ItemsService;
        private _scope: any;

        public templateUrl: string | Function;
        public link: ng.IDirectiveLinkFn | ng.IDirectivePrePost;
        public scope: boolean | Object;

        constructor(itemsService: app.ItemsService) {
            console.log("navigation.constructor()");
            console.log(this);

            this.templateUrl = "navigation/navigation.html"
            this.link = this.linkMethod;
            this.scope = {};


            this._itemsService = itemsService;
            Navigation.prototype._itemsService = itemsService;
        }

        public linkMethod($scope): void {
            console.log("navigation.link()");
            console.log(this);

            Navigation.prototype.scopeInit($scope);
        }

        //events

        //common
        scopeInit($scope): void {
            console.log("navigation.scopeInit()");
            console.log(this);

            Navigation.prototype._scope = $scope;

            $scope.itemsService = Navigation.prototype._itemsService;
            $scope.dummyTreeData = {
                "data": [
                    { "Id": 0, "Name": "item0" },
                    { "Id": 1, "Name": "item1", "Items": [] }
                ]
            };
            var treeDataSource = new kendo.data.HierarchicalDataSource({
                transport: {
                    read: function (options) {
                        console.log("treeData.dataSource.transport.readFunction()");
                        console.log("options.data.Id: ");
                        console.log(options.data.Id);

                        Navigation.prototype._itemsService.getSubItems(options.data.Id).then((success): any => {
                            console.log("treeData.dataSource.transport.readFunction().success()");
                            console.log("subItems: ");
                            console.log(success);

                            options.success(success);//$scope.dummyTreeData.data
                        },
                            (error): any => {
                                console.log("treeData.dataSource.transport.readFunction().error()");

                            });
                    }
                },
                schema: {
                    model: {
                        id: "Id",
                        hasChildren: true//"Items"
                    }
                }
            });
            $scope.treeData = null;

            ($scope as ng.IScope).$on("login", (event: ng.IAngularEvent, args: any): any => {
                console.log("navigation.login()");
                console.log("treeDataSource: ");
                console.log(treeDataSource);

                $scope.treeData = treeDataSource;
            });
            ($scope as ng.IScope).$on("logout", (event: ng.IAngularEvent, args: any): any => {
                console.log("navigation.logout()");

                $scope.treeData = null;
            });
        }
    }

    function directiveFactory(): ng.IDirectiveFactory {
        console.log("directiveFactory()");

        var factory: ng.IDirectiveFactory = function factory(itemsService: app.ItemsService): any {
            console.log("factory()");

            return new Navigation(itemsService);
        };
        factory.$inject = ["itemsService"];

        return factory;
    }

    angular.module("main").directive("navigation", directiveFactory());//
}
