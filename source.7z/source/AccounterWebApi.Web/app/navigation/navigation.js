var app;
(function (app) {
    //directive have to manipulate DOM
    var Navigation = (function () {
        function Navigation(itemsService) {
            console.log("navigation.constructor()");
            console.log(this);
            this.templateUrl = "navigation/navigation.html";
            this.link = this.linkMethod;
            this.scope = {};
            this._itemsService = itemsService;
            Navigation.prototype._itemsService = itemsService;
        }
        Navigation.prototype.linkMethod = function ($scope) {
            console.log("navigation.link()");
            console.log(this);
            Navigation.prototype.scopeInit($scope);
        };
        //events
        //common
        Navigation.prototype.scopeInit = function ($scope) {
            console.log("navigation.scopeInit()");
            console.log(this);
            Navigation.prototype._scope = $scope;
            $scope.itemsService = Navigation.prototype._itemsService;
            $scope.dummyTreeData = {
                "data": [
                    { "Id": 0, "Name": "item0" },
                    { "Id": 1, "Name": "item1", "Items": [] }
                ]
            };
            var treeDataSource = new kendo.data.HierarchicalDataSource({
                transport: {
                    read: function (options) {
                        console.log("treeData.dataSource.transport.readFunction()");
                        console.log("options.data.Id: ");
                        console.log(options.data.Id);
                        Navigation.prototype._itemsService.getSubItems(options.data.Id).then(function (success) {
                            console.log("treeData.dataSource.transport.readFunction().success()");
                            console.log("subItems: ");
                            console.log(success);
                            options.success(success); //$scope.dummyTreeData.data
                        }, function (error) {
                            console.log("treeData.dataSource.transport.readFunction().error()");
                        });
                    }
                },
                schema: {
                    model: {
                        id: "Id",
                        hasChildren: true //"Items"
                    }
                }
            });
            $scope.treeData = null;
            $scope.$on("login", function (event, args) {
                console.log("navigation.login()");
                console.log("treeDataSource: ");
                console.log(treeDataSource);
                $scope.treeData = treeDataSource;
            });
            $scope.$on("logout", function (event, args) {
                console.log("navigation.logout()");
                $scope.treeData = null;
            });
        };
        return Navigation;
    }());
    app.Navigation = Navigation;
    function directiveFactory() {
        console.log("directiveFactory()");
        var factory = function factory(itemsService) {
            console.log("factory()");
            return new Navigation(itemsService);
        };
        factory.$inject = ["itemsService"];
        return factory;
    }
    angular.module("main").directive("navigation", directiveFactory()); //
})(app || (app = {}));
//# sourceMappingURL=navigation.js.map